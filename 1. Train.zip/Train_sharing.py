import json
from os.path import join, dirname
from os import environ
from watson_developer_cloud import VisualRecognitionV3

visual_recognition = VisualRecognitionV3('2016-05-20',api_key='')


with open('.\\Mustaches.zip', 'rb') as Mustaches, \
		open('.\\NoMustaches.zip', 'rb') as NoMustaches, \
		open('.\\Spectacles.zip', 'rb') as Spectacles, \
		open('.\\NoSpectacles.zip', 'rb') as NoSpectacles, \
		open('.\\NoTie.zip', 'rb') as NoTie, \
		open('.\\Ties.zip', 'rb') as Ties:
      print(json.dumps(visual_recognition.create_classifier('FeatureAnalyzer', Mustaches_positive_examples=Mustaches, NoMustaches_positive_examples=NoMustaches, Spectacles_positive_examples=Spectacles, NoSpectacles_positive_examples=NoSpectacles, NoTie_positive_examples=NoTie, Ties_positive_examples=Ties), indent=2))

	  
	  